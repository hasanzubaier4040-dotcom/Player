package com.nova.player

import android.app.PictureInPictureParams
import android.content.ComponentName
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.provider.Settings
import android.util.Rational
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.google.common.util.concurrent.ListenableFuture
import kotlin.math.abs
import kotlin.math.roundToInt

class PlayerActivity : AppCompatActivity() {

    private val matchP = ViewGroup.LayoutParams.MATCH_PARENT
    private val wrapP = ViewGroup.LayoutParams.WRAP_CONTENT

    private lateinit var playerView: PlayerView
    private lateinit var topBar: LinearLayout
    private lateinit var titleView: TextView
    private lateinit var indicator: TextView
    private lateinit var unlockBtn: TextView
    private lateinit var nightOverlay: View
    private lateinit var btnBg: TextView
    private lateinit var btnMute: TextView
    private lateinit var btnNight: TextView
    private lateinit var btnRepeat: TextView
    private lateinit var btnRatio: TextView

    private var future: ListenableFuture<MediaController>? = null
    private var player: MediaController? = null
    private lateinit var prefs: SharedPreferences
    private lateinit var audio: AudioManager
    private val handler = Handler(Looper.getMainLooper())

    private var locked = false
    private var night = false
    private var muted = false
    private var bgPlay = false
    private var inPip = false
    private var internalLaunch = false
    private var pausedByStop = false
    private var manualOrientation = false
    private var resizeIdx = 0
    private var sleepRunnable: Runnable? = null

    // gesture state
    private var mode = 0 // 1 seek, 2 brightness, 3 volume
    private var startPos = 0L
    private var seekTarget = -1L
    private var curBright = 0.5f
    private var curVol = 0f

    private val hideIndicator = Runnable { indicator.visibility = View.GONE }
    private val hideUnlock = Runnable { if (locked) unlockBtn.visibility = View.GONE }
    private val saveTick = object : Runnable {
        override fun run() {
            savePos()
            handler.postDelayed(this, 5000)
        }
    }

    private val resizeModes = intArrayOf(
        AspectRatioFrameLayout.RESIZE_MODE_FIT,
        AspectRatioFrameLayout.RESIZE_MODE_FILL,
        AspectRatioFrameLayout.RESIZE_MODE_ZOOM,
        AspectRatioFrameLayout.RESIZE_MODE_FIXED_WIDTH,
        AspectRatioFrameLayout.RESIZE_MODE_FIXED_HEIGHT
    )
    private val resizeNames = arrayOf("Fit", "Stretch", "Crop", "Fit width", "Fit height")
    private val speeds = floatArrayOf(0.25f, 0.5f, 0.75f, 1f, 1.25f, 1.5f, 1.75f, 2f, 3f, 4f, 6f, 8f)

    private val subPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        internalLaunch = false
        if (uri != null) addSubtitle(uri)
    }

    // ---------------------------------------------------------------- lifecycle
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("nova", MODE_PRIVATE)
        audio = getSystemService(AUDIO_SERVICE) as AudioManager
        bgPlay = prefs.getBoolean("bg", false)

        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (Build.VERSION.SDK_INT >= 28) {
            window.attributes.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        buildUi()
        hideSystemBars()
        connect()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        startPlayback(intent)
    }

    override fun onStart() {
        super.onStart()
        if (pausedByStop) {
            player?.play()
            pausedByStop = false
        }
    }

    override fun onStop() {
        super.onStop()
        savePos()
        val p = player
        if (p != null && !bgPlay && !inPip && p.isPlaying) {
            p.pause()
            pausedByStop = true
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        if (isFinishing) {
            savePos()
            if (!bgPlay) {
                player?.pause()
                player?.clearMediaItems()
            }
        }
        player?.removeListener(listener)
        future?.let { MediaController.releaseFuture(it) }
        super.onDestroy()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (!internalLaunch && player?.isPlaying == true && !bgPlay) enterPip()
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        inPip = isInPictureInPictureMode
        playerView.useController = !isInPictureInPictureMode && !locked
        if (isInPictureInPictureMode) topBar.visibility = View.GONE
    }

    // ---------------------------------------------------------------- UI
    private fun hideSystemBars() {
        val c = WindowInsetsControllerCompat(window, window.decorView)
        c.hide(WindowInsetsCompat.Type.systemBars())
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }

    private fun chip(label: String, onClick: () -> Unit): TextView {
        val t = TextView(this)
        t.text = label
        t.textSize = 13f
        t.setTextColor(Color.WHITE)
        t.gravity = Gravity.CENTER
        t.setPadding(dp(12), dp(7), dp(12), dp(7))
        t.background = GradientDrawable().apply {
            setColor(Color.argb(70, 255, 255, 255))
            cornerRadius = dp(16).toFloat()
        }
        t.setOnClickListener { onClick() }
        return t
    }

    private fun buildUi() {
        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)

        playerView = PlayerView(this)
        playerView.useController = true
        playerView.controllerShowTimeoutMs = 3500
        playerView.setShowSubtitleButton(true)
        playerView.setShowNextButton(true)
        playerView.setShowPreviousButton(true)
        playerView.resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT

        val gd = GestureDetector(this, GestureListener())
        playerView.setOnTouchListener { _, ev ->
            gd.onTouchEvent(ev)
            if (ev.action == MotionEvent.ACTION_UP || ev.action == MotionEvent.ACTION_CANCEL) endGesture()
            true
        }
        playerView.setControllerVisibilityListener(PlayerView.ControllerVisibilityListener { v ->
            topBar.visibility = if (v == View.VISIBLE && !locked && !inPip) View.VISIBLE else View.GONE
        })

        nightOverlay = View(this)
        nightOverlay.setBackgroundColor(Color.argb(95, 255, 150, 40))
        nightOverlay.visibility = View.GONE

        topBar = LinearLayout(this)
        topBar.orientation = LinearLayout.VERTICAL
        topBar.setBackgroundColor(Color.argb(150, 0, 0, 0))
        topBar.setPadding(dp(8), dp(8), dp(8), dp(6))

        val row1 = LinearLayout(this)
        row1.orientation = LinearLayout.HORIZONTAL
        row1.gravity = Gravity.CENTER_VERTICAL
        val back = TextView(this)
        back.text = "←"
        back.textSize = 24f
        back.setTextColor(Color.WHITE)
        back.setPadding(dp(10), dp(4), dp(14), dp(4))
        back.setOnClickListener { finish() }
        row1.addView(back)
        titleView = TextView(this)
        titleView.setTextColor(Color.WHITE)
        titleView.textSize = 16f
        titleView.typeface = Typeface.DEFAULT_BOLD
        titleView.maxLines = 1
        titleView.ellipsize = android.text.TextUtils.TruncateAt.END
        row1.addView(titleView, LinearLayout.LayoutParams(0, wrapP, 1f))
        topBar.addView(row1)

        val scroll = HorizontalScrollView(this)
        scroll.isHorizontalScrollBarEnabled = false
        val row2 = LinearLayout(this)
        row2.orientation = LinearLayout.HORIZONTAL
        row2.setPadding(0, dp(6), 0, 0)
        fun add(c: TextView) {
            val lp = LinearLayout.LayoutParams(wrapP, wrapP)
            lp.rightMargin = dp(6)
            row2.addView(c, lp)
        }
        add(chip("⚡ Speed") { speedDialog() })
        btnRatio = chip("▭ Fit") { cycleRatio() }
        add(btnRatio)
        add(chip("🔒 Lock") { lockScreen() })
        add(chip("⟳ Rotate") { rotate() })
        btnBg = chip("🎧 BG: " + (if (bgPlay) "ON" else "OFF")) { toggleBg() }
        add(btnBg)
        btnMute = chip("🔊 Sound") { toggleMute() }
        add(btnMute)
        btnNight = chip("🌙 Night") { toggleNight() }
        add(btnNight)
        add(chip("⏲ Sleep") { sleepDialog() })
        btnRepeat = chip("🔁 Off") { cycleRepeat() }
        add(btnRepeat)
        add(chip("CC+ Subtitle file") { pickSubtitle() })
        add(chip("▣ Pop-up") { enterPip() })
        scroll.addView(row2)
        topBar.addView(scroll)

        indicator = TextView(this)
        indicator.setTextColor(Color.WHITE)
        indicator.textSize = 22f
        indicator.gravity = Gravity.CENTER
        indicator.setPadding(dp(22), dp(14), dp(22), dp(14))
        indicator.background = GradientDrawable().apply {
            setColor(Color.argb(170, 0, 0, 0))
            cornerRadius = dp(14).toFloat()
        }
        indicator.visibility = View.GONE

        unlockBtn = TextView(this)
        unlockBtn.text = "🔓"
        unlockBtn.textSize = 26f
        unlockBtn.gravity = Gravity.CENTER
        unlockBtn.setPadding(dp(16), dp(12), dp(16), dp(12))
        unlockBtn.background = GradientDrawable().apply {
            setColor(Color.argb(170, 0, 0, 0))
            cornerRadius = dp(14).toFloat()
        }
        unlockBtn.visibility = View.GONE
        unlockBtn.setOnClickListener { unlockScreen() }

        root.addView(playerView, FrameLayout.LayoutParams(matchP, matchP))
        root.addView(nightOverlay, FrameLayout.LayoutParams(matchP, matchP))
        root.addView(topBar, FrameLayout.LayoutParams(matchP, wrapP, Gravity.TOP))
        root.addView(indicator, FrameLayout.LayoutParams(wrapP, wrapP, Gravity.CENTER))
        val ulp = FrameLayout.LayoutParams(wrapP, wrapP, Gravity.START or Gravity.CENTER_VERTICAL)
        ulp.leftMargin = dp(24)
        root.addView(unlockBtn, ulp)
        setContentView(root)
    }

    private fun flash(text: String) {
        indicator.text = text
        indicator.visibility = View.VISIBLE
        handler.removeCallbacks(hideIndicator)
        handler.postDelayed(hideIndicator, 800)
    }

    // ---------------------------------------------------------------- player connection
    private val listener = object : Player.Listener {
        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            titleView.text = mediaItem?.mediaMetadata?.title ?: ""
        }

        override fun onVideoSizeChanged(videoSize: VideoSize) {
            if (!manualOrientation && !inPip && videoSize.width > 0 && videoSize.height > 0) {
                requestedOrientation = if (videoSize.width >= videoSize.height)
                    ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                else ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
            }
        }

        override fun onPlayerError(error: PlaybackException) {
            toast("Cannot play this file (" + error.errorCodeName + ")")
        }
    }

    private fun connect() {
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        val f = MediaController.Builder(this, token).buildAsync()
        future = f
        f.addListener({
            val p = try {
                f.get()
            } catch (e: Exception) {
                toast("Player service failed to start")
                finish()
                return@addListener
            }
            player = p
            playerView.player = p
            p.addListener(listener)
            titleView.text = p.currentMediaItem?.mediaMetadata?.title ?: ""
            startPlayback(intent)
            handler.postDelayed(saveTick, 5000)
        }, ContextCompat.getMainExecutor(this))
    }

    private fun buildItem(uri: Uri, title: String): MediaItem =
        MediaItem.Builder()
            .setUri(uri)
            .setMediaId(uri.toString())
            .setMediaMetadata(MediaMetadata.Builder().setTitle(title).build())
            .build()

    private fun nameOf(u: Uri): String {
        try {
            contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) {
                    val n = it.getString(0)
                    if (n != null) return n
                }
            }
        } catch (e: Exception) {
            // fall through
        }
        return u.lastPathSegment ?: "Video"
    }

    private fun startPlayback(i: Intent?) {
        val p = player ?: return
        val items: List<MediaItem>
        var start = 0
        val data = i?.data
        if (i?.action == Intent.ACTION_VIEW && data != null) {
            items = listOf(buildItem(data, nameOf(data)))
        } else {
            val list = Playlist.items
            if (list.isEmpty()) {
                finish()
                return
            }
            items = list.map { buildItem(it.uri, it.title) }
            start = Playlist.index.coerceIn(0, items.size - 1)
        }
        val wanted = items[start].mediaId
        val same = p.currentMediaItem?.mediaId == wanted && p.mediaItemCount == items.size
        if (!same) {
            val saved = prefs.getLong("pos_$wanted", 0L)
            p.setMediaItems(items, start, if (saved > 5000) saved else 0L)
            p.prepare()
        }
        titleView.text = items[start].mediaMetadata.title ?: ""
        p.playWhenReady = true
    }

    private fun savePos() {
        val p = player ?: return
        val id = p.currentMediaItem?.mediaId ?: return
        val d = p.duration
        val pos = p.currentPosition
        if (d != C.TIME_UNSET && pos > d - 10_000) prefs.edit().remove("pos_$id").apply()
        else prefs.edit().putLong("pos_$id", pos).apply()
    }

    // ---------------------------------------------------------------- gestures
    private fun endGesture() {
        if (mode == 1 && seekTarget >= 0) player?.seekTo(seekTarget)
        mode = 0
        seekTarget = -1
    }

    private inner class GestureListener : GestureDetector.SimpleOnGestureListener() {

        override fun onDown(e: MotionEvent): Boolean {
            mode = 0
            seekTarget = -1
            startPos = player?.currentPosition ?: 0L
            return true
        }

        override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
            if (locked) {
                unlockBtn.visibility = View.VISIBLE
                handler.removeCallbacks(hideUnlock)
                handler.postDelayed(hideUnlock, 2500)
            } else if (playerView.isControllerFullyVisible) {
                playerView.hideController()
            } else {
                playerView.showController()
            }
            return true
        }

        override fun onDoubleTap(e: MotionEvent): Boolean {
            if (locked) return true
            val p = player ?: return true
            val w = playerView.width.toFloat()
            val dur = p.duration
            when {
                e.x < w / 3f -> {
                    p.seekTo((p.currentPosition - 10_000).coerceAtLeast(0L))
                    flash("⏪ -10s")
                }
                e.x > w * 2f / 3f -> {
                    var t = p.currentPosition + 10_000
                    if (dur != C.TIME_UNSET) t = t.coerceAtMost(dur)
                    p.seekTo(t)
                    flash("+10s ⏩")
                }
                else -> if (p.isPlaying) p.pause() else p.play()
            }
            return true
        }

        override fun onScroll(e1: MotionEvent?, e2: MotionEvent, distanceX: Float, distanceY: Float): Boolean {
            if (locked || e1 == null) return false
            val p = player ?: return false
            val w = playerView.width.toFloat()
            val h = playerView.height.toFloat()
            if (w <= 0f || h <= 0f) return false

            if (mode == 0) {
                mode = if (abs(e2.x - e1.x) > abs(e2.y - e1.y)) 1 else if (e1.x < w / 2f) 2 else 3
                if (mode == 2) {
                    val b = window.attributes.screenBrightness
                    curBright = if (b >= 0f) b else try {
                        Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS) / 255f
                    } catch (ex: Exception) {
                        0.5f
                    }
                }
                if (mode == 3) curVol = audio.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat()
            }
            when (mode) {
                1 -> {
                    val delta = ((e2.x - e1.x) / w * 120_000f).toLong()
                    var t = startPos + delta
                    val dur = p.duration
                    t = if (dur != C.TIME_UNSET) t.coerceIn(0L, dur) else t.coerceAtLeast(0L)
                    seekTarget = t
                    val sign = if (delta >= 0) "+" else "-"
                    flash("${fmtDur(t)}  ($sign${abs(delta) / 1000}s)")
                }
                2 -> {
                    curBright = (curBright + distanceY / h * 1.5f).coerceIn(0.02f, 1f)
                    val lp = window.attributes
                    lp.screenBrightness = curBright
                    window.attributes = lp
                    flash("☀ ${(curBright * 100).roundToInt()}%")
                }
                3 -> {
                    val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                    curVol = (curVol + distanceY / h * max * 1.5f).coerceIn(0f, max.toFloat())
                    audio.setStreamVolume(AudioManager.STREAM_MUSIC, curVol.roundToInt(), 0)
                    flash("🔊 ${(curVol / max * 100).roundToInt()}%")
                }
            }
            return true
        }
    }

    // ---------------------------------------------------------------- controls
    private fun speedDialog() {
        val p = player ?: return
        val labels = speeds.map { "${it}x" }.toTypedArray()
        val cur = speeds.indexOfFirst { it == p.playbackParameters.speed }
        AlertDialog.Builder(this)
            .setTitle("Playback speed")
            .setSingleChoiceItems(labels, cur) { d, i ->
                p.setPlaybackSpeed(speeds[i])
                d.dismiss()
                flash("⚡ ${speeds[i]}x")
            }
            .show()
    }

    private fun cycleRatio() {
        resizeIdx = (resizeIdx + 1) % resizeModes.size
        playerView.resizeMode = resizeModes[resizeIdx]
        btnRatio.text = "▭ " + resizeNames[resizeIdx]
        flash(resizeNames[resizeIdx])
    }

    private fun lockScreen() {
        locked = true
        playerView.hideController()
        playerView.useController = false
        topBar.visibility = View.GONE
        unlockBtn.visibility = View.VISIBLE
        handler.removeCallbacks(hideUnlock)
        handler.postDelayed(hideUnlock, 2500)
        flash("🔒 Screen locked")
    }

    private fun unlockScreen() {
        locked = false
        unlockBtn.visibility = View.GONE
        playerView.useController = true
        playerView.showController()
        flash("🔓 Unlocked")
    }

    private fun rotate() {
        manualOrientation = true
        requestedOrientation =
            if (resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE)
                ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
            else ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
    }

    private fun toggleBg() {
        bgPlay = !bgPlay
        prefs.edit().putBoolean("bg", bgPlay).apply()
        btnBg.text = "🎧 BG: " + (if (bgPlay) "ON" else "OFF")
        flash(if (bgPlay) "Background play ON" else "Background play OFF")
    }

    private fun toggleMute() {
        muted = !muted
        player?.volume = if (muted) 0f else 1f
        btnMute.text = if (muted) "🔇 Muted" else "🔊 Sound"
    }

    private fun toggleNight() {
        night = !night
        nightOverlay.visibility = if (night) View.VISIBLE else View.GONE
        btnNight.text = if (night) "🌙 Night ON" else "🌙 Night"
    }

    private fun cycleRepeat() {
        val p = player ?: return
        val next = when (p.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ONE
            Player.REPEAT_MODE_ONE -> Player.REPEAT_MODE_ALL
            else -> Player.REPEAT_MODE_OFF
        }
        p.repeatMode = next
        btnRepeat.text = when (next) {
            Player.REPEAT_MODE_ONE -> "🔂 One"
            Player.REPEAT_MODE_ALL -> "🔁 All"
            else -> "🔁 Off"
        }
    }

    private fun sleepDialog() {
        val labels = arrayOf("Off", "15 min", "30 min", "45 min", "60 min", "90 min")
        val mins = intArrayOf(0, 15, 30, 45, 60, 90)
        AlertDialog.Builder(this)
            .setTitle("Sleep timer")
            .setItems(labels) { _, i ->
                sleepRunnable?.let { handler.removeCallbacks(it) }
                sleepRunnable = null
                if (mins[i] > 0) {
                    val r = Runnable {
                        player?.pause()
                        toast("Sleep timer: stopped")
                    }
                    sleepRunnable = r
                    handler.postDelayed(r, mins[i] * 60_000L)
                    toast("Will stop in ${mins[i]} min")
                } else {
                    toast("Sleep timer off")
                }
            }
            .show()
    }

    private fun enterPip() {
        if (Build.VERSION.SDK_INT < 26 ||
            !packageManager.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)
        ) {
            toast("Pop-up window not supported on this phone")
            return
        }
        var w = 16
        var h = 9
        val vs = player?.videoSize
        if (vs != null && vs.width > 0 && vs.height > 0) {
            w = vs.width
            h = vs.height
        }
        val ratio = (w.toFloat() / h).coerceIn(0.42f, 2.38f)
        try {
            enterPictureInPictureMode(
                PictureInPictureParams.Builder()
                    .setAspectRatio(Rational((ratio * 1000).toInt(), 1000))
                    .build()
            )
        } catch (e: Exception) {
            toast("Enable 'Picture-in-picture' for Nova Player in phone settings")
        }
    }

    private fun pickSubtitle() {
        internalLaunch = true
        subPicker.launch(arrayOf("*/*"))
    }

    private fun addSubtitle(uri: Uri) {
        val p = player ?: return
        val cur = p.currentMediaItem ?: return
        val idx = p.currentMediaItemIndex
        val name = nameOf(uri).lowercase()
        val mime = when {
            name.endsWith(".vtt") -> MimeTypes.TEXT_VTT
            name.endsWith(".ass") || name.endsWith(".ssa") -> MimeTypes.TEXT_SSA
            name.endsWith(".ttml") || name.endsWith(".xml") -> MimeTypes.APPLICATION_TTML
            else -> MimeTypes.APPLICATION_SUBRIP
        }
        val sub = MediaItem.SubtitleConfiguration.Builder(uri)
            .setMimeType(mime)
            .setLanguage("und")
            .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
            .build()
        val item = cur.buildUpon().setSubtitleConfigurations(listOf(sub)).build()
        val pos = p.currentPosition
        p.replaceMediaItem(idx, item)
        p.seekTo(idx, pos)
        toast("Subtitle added")
    }
}
