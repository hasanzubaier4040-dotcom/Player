package com.nova.player

import android.Manifest
import android.content.ContentUris
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.text.TextUtils
import android.view.Gravity
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.widget.doAfterTextChanged
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

data class Row(val title: String, val sub: String, val video: Video?, val folder: String?)

class MainActivity : AppCompatActivity() {

    private val bg = Color.parseColor("#121212")
    private val accent = Color.parseColor("#3B82F6")
    private val gray = Color.parseColor("#9CA3AF")

    private lateinit var titleView: TextView
    private lateinit var search: EditText
    private lateinit var tabFolders: TextView
    private lateinit var tabAll: TextView
    private lateinit var empty: TextView
    private lateinit var recycler: RecyclerView

    private val rows = ArrayList<Row>()
    private lateinit var adapter: RowAdapter
    private var currentShown: List<Video> = emptyList()
    private var tab = 0
    private var currentFolder: String? = null
    private var sortMode = 1

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { loadVideos() }

    private val deleteLauncher =
        registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { r ->
            if (r.resultCode == RESULT_OK) loadVideos()
        }

    private val backCb = object : OnBackPressedCallback(false) {
        override fun handleOnBackPressed() {
            currentFolder = null
            isEnabled = false
            refresh()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        onBackPressedDispatcher.addCallback(this, backCb)
        buildUi()
        loadVideos()
    }

    private fun iconBtn(t: String, onClick: () -> Unit): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = 20f
        v.setTextColor(Color.WHITE)
        v.gravity = Gravity.CENTER
        v.setPadding(dp(12), dp(8), dp(12), dp(8))
        v.setOnClickListener { onClick() }
        return v
    }

    private fun buildUi() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(bg)

        val header = LinearLayout(this)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL
        header.setPadding(dp(16), dp(12), dp(4), dp(4))
        titleView = TextView(this)
        titleView.text = "Nova Player"
        titleView.textSize = 22f
        titleView.typeface = Typeface.DEFAULT_BOLD
        titleView.setTextColor(Color.WHITE)
        header.addView(titleView, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(iconBtn("⇅") { sortDialog() })
        header.addView(iconBtn("⟳") { loadVideos() })
        root.addView(header)

        search = EditText(this)
        search.hint = "Search videos"
        search.setHintTextColor(gray)
        search.setTextColor(Color.WHITE)
        search.textSize = 15f
        search.maxLines = 1
        search.inputType = android.text.InputType.TYPE_CLASS_TEXT
        search.setPadding(dp(14), dp(10), dp(14), dp(10))
        search.background = GradientDrawable().apply {
            setColor(Color.parseColor("#1E1E1E"))
            cornerRadius = dp(10).toFloat()
        }
        search.doAfterTextChanged { refresh() }
        val sp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        sp.setMargins(dp(16), dp(4), dp(16), dp(4))
        root.addView(search, sp)

        val tabs = LinearLayout(this)
        tabs.orientation = LinearLayout.HORIZONTAL
        tabFolders = tabView("Folders") { setTab(0) }
        tabAll = tabView("All videos") { setTab(1) }
        tabs.addView(tabFolders, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        tabs.addView(tabAll, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(tabs)

        val frame = FrameLayout(this)
        recycler = RecyclerView(this)
        recycler.layoutManager = LinearLayoutManager(this)
        adapter = RowAdapter(rows, { onRow(it) }, { onRowLong(it) })
        recycler.adapter = adapter
        frame.addView(recycler, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        empty = TextView(this)
        empty.setTextColor(gray)
        empty.textSize = 16f
        empty.gravity = Gravity.CENTER
        empty.visibility = android.view.View.GONE
        empty.setOnClickListener { if (!hasPerm()) requestPerms() else loadVideos() }
        frame.addView(empty, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.addView(frame, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        setContentView(root)
        updateTabs()
    }

    private fun tabView(label: String, onClick: () -> Unit): TextView {
        val t = TextView(this)
        t.text = label
        t.textSize = 15f
        t.gravity = Gravity.CENTER
        t.setPadding(dp(8), dp(12), dp(8), dp(12))
        t.setOnClickListener { onClick() }
        return t
    }

    private fun updateTabs() {
        tabFolders.setTextColor(if (tab == 0) accent else gray)
        tabAll.setTextColor(if (tab == 1) accent else gray)
        tabFolders.typeface = if (tab == 0) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        tabAll.typeface = if (tab == 1) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
    }

    private fun setTab(t: Int) {
        tab = t
        currentFolder = null
        backCb.isEnabled = false
        updateTabs()
        refresh()
    }

    // ---------------------------------------------------------------- permissions & scan
    private fun hasPerm(): Boolean {
        val p = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO
        else Manifest.permission.READ_EXTERNAL_STORAGE
        return ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED
    }

    private fun requestPerms() {
        val p = ArrayList<String>()
        if (Build.VERSION.SDK_INT >= 33) {
            p.add(Manifest.permission.READ_MEDIA_VIDEO)
            p.add(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            p.add(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
        permLauncher.launch(p.toTypedArray())
    }

    @Suppress("DEPRECATION")
    private fun loadVideos() {
        if (!hasPerm()) {
            Library.all = emptyList()
            refresh()
            requestPerms()
            return
        }
        Thread {
            val out = ArrayList<Video>()
            val base = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            val proj = arrayOf(
                MediaStore.Video.Media._ID,
                MediaStore.Video.Media.DISPLAY_NAME,
                MediaStore.Video.Media.DURATION,
                MediaStore.Video.Media.SIZE,
                MediaStore.Video.Media.DATE_ADDED,
                MediaStore.Video.Media.BUCKET_DISPLAY_NAME,
                MediaStore.Video.Media.DATA
            )
            try {
                contentResolver.query(base, proj, null, null, null)?.use { c ->
                    val iId = c.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                    val iName = c.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
                    val iDur = c.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
                    val iSize = c.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
                    val iDate = c.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_ADDED)
                    val iBucket = c.getColumnIndexOrThrow(MediaStore.Video.Media.BUCKET_DISPLAY_NAME)
                    val iData = c.getColumnIndexOrThrow(MediaStore.Video.Media.DATA)
                    while (c.moveToNext()) {
                        val id = c.getLong(iId)
                        out.add(
                            Video(
                                id,
                                ContentUris.withAppendedId(base, id),
                                c.getString(iName) ?: "video",
                                c.getLong(iDur),
                                c.getLong(iSize),
                                c.getLong(iDate),
                                c.getString(iBucket) ?: "Unknown",
                                c.getString(iData)
                            )
                        )
                    }
                }
            } catch (e: Exception) {
                // ignore, show empty list
            }
            Library.all = out
            runOnUiThread { refresh() }
        }.start()
    }

    // ---------------------------------------------------------------- list
    private fun refresh() {
        val q = search.text.toString().trim().lowercase()
        rows.clear()
        val vids = Library.all.filter { q.isEmpty() || it.title.lowercase().contains(q) }
        if (tab == 0 && currentFolder == null && q.isEmpty()) {
            vids.groupBy { it.folder }
                .toSortedMap(String.CASE_INSENSITIVE_ORDER)
                .forEach { (f, l) -> rows.add(Row(f, "${l.size} videos", null, f)) }
            currentShown = emptyList()
        } else {
            val cmp: Comparator<Video> = when (sortMode) {
                0 -> Comparator { a, b -> a.title.compareTo(b.title, true) }
                2 -> Comparator { a, b -> b.duration.compareTo(a.duration) }
                3 -> Comparator { a, b -> b.size.compareTo(a.size) }
                else -> Comparator { a, b -> b.date.compareTo(a.date) }
            }
            val base = if (tab == 0 && currentFolder != null) vids.filter { it.folder == currentFolder } else vids
            val shown = base.sortedWith(cmp)
            shown.forEach {
                rows.add(Row(it.title, "${fmtDur(it.duration)}  •  ${fmtSize(it.size)}  •  ${it.folder}", it, null))
            }
            currentShown = shown
        }
        adapter.notifyDataSetChanged()
        titleView.text = currentFolder ?: "Nova Player"
        if (rows.isEmpty()) {
            empty.text = if (!hasPerm()) "Permission needed.\nTap here to allow video access." else "No videos found"
            empty.visibility = android.view.View.VISIBLE
        } else {
            empty.visibility = android.view.View.GONE
        }
    }

    private fun onRow(r: Row) {
        if (r.folder != null) {
            currentFolder = r.folder
            backCb.isEnabled = true
            refresh()
        } else {
            r.video?.let { play(it) }
        }
    }

    private fun play(v: Video) {
        val list = if (currentShown.contains(v)) currentShown else listOf(v)
        Playlist.items = list
        Playlist.index = list.indexOf(v).coerceAtLeast(0)
        startActivity(Intent(this, PlayerActivity::class.java))
    }

    private fun onRowLong(r: Row) {
        val v = r.video ?: return
        val labels = arrayOf("▶ Play", "Share", "Info", "Delete")
        AlertDialog.Builder(this)
            .setTitle(v.title)
            .setItems(labels) { _, i ->
                when (i) {
                    0 -> play(v)
                    1 -> share(v)
                    2 -> info(v)
                    3 -> confirmDelete(v)
                }
            }
            .show()
    }

    private fun share(v: Video) {
        val i = Intent(Intent.ACTION_SEND)
        i.type = "video/*"
        i.putExtra(Intent.EXTRA_STREAM, v.uri)
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startActivity(Intent.createChooser(i, "Share video"))
    }

    private fun info(v: Video) {
        AlertDialog.Builder(this)
            .setTitle("Video info")
            .setMessage(
                "Name: ${v.title}\nFolder: ${v.folder}\nDuration: ${fmtDur(v.duration)}\n" +
                    "Size: ${fmtSize(v.size)}\nPath: ${v.path ?: "-"}"
            )
            .setPositiveButton("OK", null)
            .show()
    }

    private fun confirmDelete(v: Video) {
        AlertDialog.Builder(this)
            .setTitle("Delete video?")
            .setMessage(v.title)
            .setPositiveButton("Delete") { _, _ -> deleteVideo(v) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun deleteVideo(v: Video) {
        if (Build.VERSION.SDK_INT >= 30) {
            val pi = MediaStore.createDeleteRequest(contentResolver, listOf(v.uri))
            deleteLauncher.launch(IntentSenderRequest.Builder(pi.intentSender).build())
        } else {
            try {
                contentResolver.delete(v.uri, null, null)
                loadVideos()
            } catch (e: Exception) {
                toast("Delete not allowed on this Android version")
            }
        }
    }

    private fun sortDialog() {
        val labels = arrayOf("Name", "Date added (newest)", "Duration (longest)", "Size (largest)")
        AlertDialog.Builder(this)
            .setTitle("Sort by")
            .setSingleChoiceItems(labels, sortMode) { d, i ->
                sortMode = i
                d.dismiss()
                refresh()
            }
            .show()
    }
}

class RowAdapter(
    private val rows: List<Row>,
    private val onClick: (Row) -> Unit,
    private val onLong: (Row) -> Unit
) : RecyclerView.Adapter<RowAdapter.VH>() {

    class VH(
        val root: LinearLayout,
        val thumb: ImageView,
        val icon: TextView,
        val title: TextView,
        val sub: TextView
    ) : RecyclerView.ViewHolder(root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val c = parent.context
        val root = LinearLayout(c)
        root.orientation = LinearLayout.HORIZONTAL
        root.gravity = Gravity.CENTER_VERTICAL
        root.setPadding(c.dp(12), c.dp(6), c.dp(12), c.dp(6))
        root.layoutParams = RecyclerView.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        )

        val frame = FrameLayout(c)
        val thumb = ImageView(c)
        thumb.scaleType = ImageView.ScaleType.CENTER_CROP
        thumb.setBackgroundColor(Color.parseColor("#262626"))
        frame.addView(thumb, FrameLayout.LayoutParams(c.dp(112), c.dp(68)))
        val icon = TextView(c)
        icon.text = "📁"
        icon.textSize = 28f
        icon.gravity = Gravity.CENTER
        icon.visibility = android.view.View.GONE
        frame.addView(icon, FrameLayout.LayoutParams(c.dp(112), c.dp(68)))
        root.addView(frame, LinearLayout.LayoutParams(c.dp(112), c.dp(68)))

        val col = LinearLayout(c)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(c.dp(12), 0, 0, 0)
        val title = TextView(c)
        title.setTextColor(Color.WHITE)
        title.textSize = 15f
        title.maxLines = 2
        title.ellipsize = TextUtils.TruncateAt.END
        val sub = TextView(c)
        sub.setTextColor(Color.parseColor("#9CA3AF"))
        sub.textSize = 12f
        sub.maxLines = 1
        sub.ellipsize = TextUtils.TruncateAt.END
        col.addView(title)
        col.addView(sub)
        root.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        return VH(root, thumb, icon, title, sub)
    }

    override fun getItemCount(): Int = rows.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val r = rows[position]
        h.title.text = r.title
        h.sub.text = r.sub
        val v = r.video
        if (v != null) {
            h.icon.visibility = android.view.View.GONE
            Thumbs.load(h.root.context, v, h.thumb)
        } else {
            h.thumb.tag = null
            h.thumb.setImageDrawable(null)
            h.icon.visibility = android.view.View.VISIBLE
        }
        h.root.setOnClickListener { onClick(r) }
        h.root.setOnLongClickListener {
            onLong(r)
            true
        }
    }
}
