package com.nova.player

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.util.LruCache
import android.util.Size
import android.widget.ImageView
import java.util.concurrent.Executors

data class Video(
    val id: Long,
    val uri: Uri,
    val title: String,
    val duration: Long,
    val size: Long,
    val date: Long,
    val folder: String,
    val path: String?
)

object Library {
    @Volatile
    var all: List<Video> = emptyList()
}

object Playlist {
    var items: List<Video> = emptyList()
    var index: Int = 0
}

object Thumbs {
    private val cache = LruCache<Long, Bitmap>(120)
    private val pool = Executors.newFixedThreadPool(3)

    @Suppress("DEPRECATION")
    fun load(ctx: Context, v: Video, iv: ImageView) {
        iv.tag = v.id
        val hit = cache.get(v.id)
        if (hit != null) {
            iv.setImageBitmap(hit)
            return
        }
        iv.setImageDrawable(null)
        val app = ctx.applicationContext
        pool.execute {
            val bmp: Bitmap? = try {
                if (Build.VERSION.SDK_INT >= 29) {
                    app.contentResolver.loadThumbnail(v.uri, Size(320, 200), null)
                } else {
                    MediaStore.Video.Thumbnails.getThumbnail(
                        app.contentResolver, v.id, MediaStore.Video.Thumbnails.MINI_KIND, null
                    )
                }
            } catch (e: Exception) {
                null
            }
            if (bmp != null) {
                cache.put(v.id, bmp)
                iv.post { if (iv.tag == v.id) iv.setImageBitmap(bmp) }
            }
        }
    }
}
